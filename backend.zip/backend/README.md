# Backend - API de Gestión de Proyectos

Backend API REST para el sistema de gestión de proyectos empresariales.

## 🚀 Tecnologías

- **Node.js** + **Express** - Servidor y framework web
- **PostgreSQL** - Base de datos relacional
- **JWT** - Autenticación y autorización
- **bcrypt** - Encriptación de contraseñas

## 📋 Requisitos Previos

- Node.js 18+ instalado
- PostgreSQL 14+ instalado y corriendo
- npm o yarn

## 🔧 Instalación

1. **Instalar dependencias:**
   ```bash
   npm install
   ```

2. **Configurar variables de entorno:**
   
   Copia el archivo `.env.example` a `.env` y ajusta los valores:
   ```bash
   cp .env.example .env
   ```

3. **Crear la base de datos en PostgreSQL:**
   ```bash
   # Conectarse a PostgreSQL
   psql -U postgres
   
   # Crear la base de datos
   CREATE DATABASE intermodular;
   
   # Salir
   \q
   ```

4. **Inicializar la base de datos (crear tablas y datos de prueba):**
   ```bash
   npm run init-db
   ```

## 🎯 Uso

### Desarrollo
```bash
npm run dev
```

El servidor se iniciará en `http://localhost:4000`

### Producción
```bash
npm start
```

## 📚 Endpoints Disponibles

### Autenticación
- `POST /api/auth/login` - Iniciar sesión
- `POST /api/auth/register` - Registrar nuevo usuario
- `GET /api/auth/me` - Obtener usuario actual (requiere token)

### Proyectos
- `GET /api/proyectos` - Listar todos los proyectos
- `GET /api/proyectos/:id` - Obtener un proyecto
- `POST /api/proyectos` - Crear proyecto (requiere autenticación)
- `PUT /api/proyectos/:id` - Actualizar proyecto (requiere autenticación)
- `DELETE /api/proyectos/:id` - Eliminar proyecto (requiere autenticación)
- `GET /api/proyectos/:id/team` - Obtener equipo del proyecto

### Clientes
- `GET /api/clientes` - Listar clientes
- `GET /api/clientes/:id` - Obtener un cliente
- `POST /api/clientes` - Crear cliente (requiere autenticación)
- `PUT /api/clientes/:id` - Actualizar cliente (requiere autenticación)
- `DELETE /api/clientes/:id` - Eliminar cliente (requiere autenticación)

### Personal
- `GET /api/personal` - Listar personal
- `GET /api/personal/:id` - Obtener una persona
- `POST /api/personal` - Crear personal (requiere autenticación)
- `PUT /api/personal/:id` - Actualizar personal (requiere autenticación)
- `DELETE /api/personal/:id` - Eliminar personal (requiere autenticación)

### Tareas
- `GET /api/tareas` - Listar tareas
- `GET /api/tareas/:id` - Obtener una tarea
- `GET /api/tareas/proyecto/:idProyecto` - Tareas de un proyecto
- `POST /api/tareas` - Crear tarea (requiere autenticación)
- `PUT /api/tareas/:id` - Actualizar tarea (requiere autenticación)
- `DELETE /api/tareas/:id` - Eliminar tarea (requiere autenticación)

## 🔐 Autenticación

Para endpoints protegidos, incluye el token JWT en el header:
```
Authorization: Bearer <tu_token_jwt>
```

### Usuarios de Prueba

Después de ejecutar `npm run init-db`, tendrás estos usuarios:

- **Email:** admin@test.com  
  **Password:** admin123  
  **Rol:** admin

- **Email:** maria@test.com  
  **Password:** admin123  
  **Rol:** project_manager

- **Email:** juan@test.com  
  **Password:** admin123  
  **Rol:** developer

## 📁 Estructura del Proyecto

```
backend/
├── config/
│   └── database.js       # Configuración de PostgreSQL
├── controllers/
│   ├── authController.js
│   └── proyectosController.js
├── db/
│   ├── schema.sql        # Esquema de base de datos
│   └── seed.sql          # Datos de prueba
├── middleware/
│   └── auth.js           # Middleware de autenticación
├── models/
│   ├── Cliente.js
│   ├── Personal.js
│   ├── Proyecto.js
│   ├── Tarea.js
│   └── Usuario.js
├── routes/
│   ├── auth.js
│   ├── clientes.js
│   ├── personal.js
│   ├── proyectos.js
│   └── tareas.js
├── scripts/
│   └── initDb.js         # Script de inicialización
├── .env                  # Variables de entorno
├── .env.example          # Plantilla de variables
├── package.json
└── server.js             # Punto de entrada
```

## 🐛 Troubleshooting

### Error de conexión a PostgreSQL
- Verifica que PostgreSQL esté corriendo
- Comprueba las credenciales en `.env`
- Asegúrate de que la base de datos `intermodular` existe

### Error "Cannot find module"
```bash
npm install
```

### Reiniciar la base de datos
```bash
npm run init-db
```

## 📝 Notas

- El servidor usa el puerto 4000 por defecto
- CORS está habilitado para desarrollo
- Los tokens JWT expiran en 24 horas
- Las contraseñas se encriptan con bcrypt (10 rounds)
