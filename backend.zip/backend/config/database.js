import mysql from 'mysql2/promise';
import dotenv from 'dotenv';

dotenv.config();

const pool = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 3306,
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || 'password123',
    database: process.env.DB_NAME || 'intermodular',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    charset: 'utf8mb4',
    // Asegurar que las conexiones usen UTF-8
    connectTimeout: 60000,
    acquireTimeout: 60000
});

// Test connection y configurar charset
(async () => {
    try {
        const connection = await pool.getConnection();
        // Asegurar que la conexión use UTF-8
        await connection.query('SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci');
        await connection.query('SET CHARACTER SET utf8mb4');
        console.log('✅ Conectado a MySQL');
        connection.release();
    } catch (err) {
        console.error('❌ Error en la conexión a MySQL:', err);
    }
})();

export default pool;
