import Proyecto from '../models/Proyecto.js';

export const getAllProyectos = async (req, res) => {
    try {
        const proyectos = await Proyecto.getAll();
        res.json(proyectos);
    } catch (error) {
        console.error('Error al obtener proyectos:', error);
        res.status(500).json({ message: 'Error al obtener proyectos' });
    }
};

export const getProyectoById = async (req, res) => {
    try {
        const proyecto = await Proyecto.getById(req.params.id);
        if (!proyecto) {
            return res.status(404).json({ message: 'Proyecto no encontrado' });
        }
        res.json(proyecto);
    } catch (error) {
        console.error('Error al obtener proyecto:', error);
        res.status(500).json({ message: 'Error al obtener proyecto' });
    }
};

export const createProyecto = async (req, res) => {
    try {
        console.log('📝 Datos recibidos:', JSON.stringify(req.body, null, 2));
        const proyecto = await Proyecto.create(req.body);
        res.status(201).json(proyecto);
    } catch (error) {
        console.error('❌ Error al crear proyecto:', error);
        console.error('❌ Stack:', error.stack);
        res.status(500).json({ 
            message: 'Error al crear proyecto',
            error: error.message,
            details: process.env.NODE_ENV === 'development' ? error.stack : undefined
        });
    }
};

export const updateProyecto = async (req, res) => {
    try {
        const proyecto = await Proyecto.update(req.params.id, req.body);
        if (!proyecto) {
            return res.status(404).json({ message: 'Proyecto no encontrado' });
        }
        res.json(proyecto);
    } catch (error) {
        console.error('Error al actualizar proyecto:', error);
        res.status(500).json({ 
            message: 'Error al actualizar proyecto',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
};

export const deleteProyecto = async (req, res) => {
    try {
        const proyecto = await Proyecto.delete(req.params.id);
        if (!proyecto) {
            return res.status(404).json({ message: 'Proyecto no encontrado' });
        }
        res.json({ message: 'Proyecto eliminado', proyecto });
    } catch (error) {
        console.error('Error al eliminar proyecto:', error);
        res.status(500).json({ message: 'Error al eliminar proyecto' });
    }
};

export const getProyectoTeam = async (req, res) => {
    try {
        const team = await Proyecto.getTeam(req.params.id);
        res.json(team);
    } catch (error) {
        console.error('Error al obtener equipo del proyecto:', error);
        res.status(500).json({ message: 'Error al obtener equipo' });
    }
};
