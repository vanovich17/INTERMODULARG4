-- ============================================================
-- BASE DE DATOS: Gestión de Proyectos
-- Archivo completo: Schema + Datos iniciales
-- Charset: utf8mb4 (soporta ñ, tildes y caracteres especiales)
-- ============================================================

-- Configurar codificación UTF-8 antes de cualquier operación
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;
SET CHARACTER SET utf8mb4;
SET character_set_client = utf8mb4;
SET character_set_connection = utf8mb4;
SET character_set_results = utf8mb4;

-- Crear base de datos con charset utf8mb4
CREATE DATABASE IF NOT EXISTS gestion_proyectos 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE gestion_proyectos;

-- Asegurar UTF-8 después de cambiar de base de datos
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;
SET CHARACTER SET utf8mb4;

-- ============================================================
-- 1) TABLAS
-- ============================================================

-- Tabla de Usuarios (para autenticación)
CREATE TABLE IF NOT EXISTS usuarios (
  id_usuario INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  rol VARCHAR(50) DEFAULT 'usuario',
  fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de Clientes
CREATE TABLE IF NOT EXISTS cliente (
  id_cliente INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(150) NOT NULL,
  contacto_email VARCHAR(150),
  telefono VARCHAR(30),
  direccion VARCHAR(255),
  creado_en DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de Roles
CREATE TABLE IF NOT EXISTS rol (
  id_rol INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL UNIQUE,
  descripcion VARCHAR(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de Proyectos
CREATE TABLE IF NOT EXISTS proyecto (
  id_proyecto INT AUTO_INCREMENT PRIMARY KEY,
  id_cliente INT NOT NULL,
  nombre VARCHAR(150) NOT NULL,
  descripcion TEXT,
  fecha_inicio DATE,
  fecha_fin DATE,
  estado ENUM('Activo','Finalizado','Suspendido') DEFAULT 'Activo',
  creado_en DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (id_cliente) REFERENCES cliente(id_cliente)
      ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de Personal del Equipo
CREATE TABLE IF NOT EXISTS personal_equipo (
  id_personal INT AUTO_INCREMENT PRIMARY KEY,
  id_proyecto INT NOT NULL,
  id_rol INT NOT NULL,
  nombre VARCHAR(150) NOT NULL,
  email VARCHAR(150),
  telefono VARCHAR(30),
  fecha_agregado DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (id_proyecto) REFERENCES proyecto(id_proyecto) ON DELETE CASCADE,
  FOREIGN KEY (id_rol) REFERENCES rol(id_rol) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de Tareas
CREATE TABLE IF NOT EXISTS tarea (
  id_tarea INT AUTO_INCREMENT PRIMARY KEY,
  id_proyecto INT NOT NULL,
  titulo VARCHAR(200) NOT NULL,
  descripcion TEXT,
  prioridad TINYINT NOT NULL DEFAULT 3,
  estado ENUM('Pendiente','En progreso','Bloqueada','Completada') DEFAULT 'Pendiente',
  id_responsable INT NULL,
  fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP,
  fecha_vencimiento DATE NULL,
  fecha_ultima_modificacion DATETIME DEFAULT CURRENT_TIMESTAMP
     ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (id_proyecto) REFERENCES proyecto(id_proyecto) ON DELETE CASCADE,
  FOREIGN KEY (id_responsable) REFERENCES personal_equipo(id_personal) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabla de Log de Cambios en Tareas
CREATE TABLE IF NOT EXISTS tarea_log (
  id_log INT AUTO_INCREMENT PRIMARY KEY,
  id_tarea INT NOT NULL,
  campo VARCHAR(100) NOT NULL,
  valor_anterior TEXT,
  valor_nuevo TEXT,
  cambiado_en DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (id_tarea) REFERENCES tarea(id_tarea) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 2) FUNCIONES
-- ============================================================

DROP FUNCTION IF EXISTS fn_total_tareas_proyecto;
DELIMITER //
CREATE FUNCTION fn_total_tareas_proyecto(p_id_proyecto INT)
RETURNS INT
DETERMINISTIC
READS SQL DATA
BEGIN
  DECLARE v_total INT;
  SELECT COUNT(*) INTO v_total FROM tarea WHERE id_proyecto = p_id_proyecto;
  RETURN IFNULL(v_total,0);
END;
//
DELIMITER ;

DROP FUNCTION IF EXISTS fn_porcentaje_tareas_hechas;
DELIMITER //
CREATE FUNCTION fn_porcentaje_tareas_hechas(p_id_proyecto INT)
RETURNS DECIMAL(5,2)
DETERMINISTIC
READS SQL DATA
BEGIN
  DECLARE v_total INT DEFAULT 0;
  DECLARE v_hechas INT DEFAULT 0;
  SELECT COUNT(*) INTO v_total FROM tarea WHERE id_proyecto = p_id_proyecto;
  SELECT COUNT(*) INTO v_hechas FROM tarea WHERE id_proyecto = p_id_proyecto AND estado='Completada';
  IF v_total = 0 THEN
    RETURN 0.00;
  END IF;
  RETURN ROUND((v_hechas / v_total) * 100,2);
END;
//
DELIMITER ;

-- ============================================================
-- 3) PROCEDIMIENTOS ALMACENADOS
-- ============================================================

DROP PROCEDURE IF EXISTS pr_crear_tarea;
DELIMITER //
CREATE PROCEDURE pr_crear_tarea(
  IN p_id_proyecto INT,
  IN p_titulo VARCHAR(200),
  IN p_desc TEXT,
  IN p_prioridad TINYINT,
  IN p_id_responsable INT
)
BEGIN
  INSERT INTO tarea(id_proyecto, titulo, descripcion, prioridad, id_responsable, estado)
  VALUES (p_id_proyecto, p_titulo, p_desc, p_prioridad, p_id_responsable, 'Pendiente');
  SELECT LAST_INSERT_ID() AS id_creada;
END;
//
DELIMITER ;

DROP PROCEDURE IF EXISTS pr_cambiar_estado_tarea;
DELIMITER //
CREATE PROCEDURE pr_cambiar_estado_tarea(
  IN p_id_tarea INT,
  IN p_nuevo_estado VARCHAR(50)
)
BEGIN
  DECLARE v_actual VARCHAR(50);
  
  SELECT estado INTO v_actual FROM tarea WHERE id_tarea = p_id_tarea;
  
  IF v_actual IS NULL THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Tarea no existe';
  END IF;
  
  IF p_nuevo_estado NOT IN ('Pendiente','En progreso','Bloqueada','Completada') THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Estado no válido';
  END IF;

  IF v_actual = 'Completada' AND p_nuevo_estado <> 'Completada' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='No se puede cambiar una tarea completada';
  END IF;

  UPDATE tarea SET estado = p_nuevo_estado WHERE id_tarea = p_id_tarea;
END;
//
DELIMITER ;

-- ============================================================
-- 4) VISTAS
-- ============================================================

CREATE OR REPLACE VIEW v_tareas_proyecto AS
SELECT t.*, p.nombre AS nombre_proyecto, c.nombre AS nombre_cliente
FROM tarea t
JOIN proyecto p ON t.id_proyecto = p.id_proyecto
JOIN cliente c ON p.id_cliente = c.id_cliente;

CREATE OR REPLACE VIEW v_resumen_proyecto AS
SELECT 
  p.id_proyecto,
  p.nombre AS proyecto,
  fn_total_tareas_proyecto(p.id_proyecto) AS total_tareas,
  fn_porcentaje_tareas_hechas(p.id_proyecto) AS porcentaje
FROM proyecto p;

-- ============================================================
-- 5) TRIGGERS
-- ============================================================

DROP TRIGGER IF EXISTS trg_tarea_estado_valido;
DELIMITER //
CREATE TRIGGER trg_tarea_estado_valido
BEFORE UPDATE ON tarea
FOR EACH ROW
BEGIN
  IF NEW.estado NOT IN ('Pendiente','En progreso','Bloqueada','Completada') THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Estado inválido';
  END IF;

  IF OLD.estado='Completada' AND NEW.estado<>'Completada' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='No se puede revertir una tarea completada';
  END IF;
END;
//
DELIMITER ;

DROP TRIGGER IF EXISTS trg_log_cambios_tarea;
DELIMITER //
CREATE TRIGGER trg_log_cambios_tarea
AFTER UPDATE ON tarea
FOR EACH ROW
BEGIN
  IF OLD.estado <> NEW.estado THEN
    INSERT INTO tarea_log(id_tarea,campo,valor_anterior,valor_nuevo)
    VALUES (OLD.id_tarea,'estado',OLD.estado,NEW.estado);
  END IF;

  IF OLD.prioridad <> NEW.prioridad THEN
    INSERT INTO tarea_log(id_tarea,campo,valor_anterior,valor_nuevo)
    VALUES (OLD.id_tarea,'prioridad',OLD.prioridad,NEW.prioridad);
  END IF;
END;
//
DELIMITER ;

-- ============================================================
-- 6) DATOS INICIALES
-- ============================================================

-- USUARIOS (para autenticación)
INSERT INTO usuarios (nombre, email, password_hash, rol) VALUES
('Administrador', 'admin@test.com', '$2b$10$EGs0S3Qfa9iPtMY8XDjvy.UVTqgOF.1qcNPevyGgjtz3SjiBeohtu', 'admin'),
('María González', 'maria@test.com', '$2b$10$EGs0S3Qfa9iPtMY8XDjvy.UVTqgOF.1qcNPevyGgjtz3SjiBeohtu', 'project_manager'),
('Juan López', 'juan@test.com', '$2b$10$EGs0S3Qfa9iPtMY8XDjvy.UVTqgOF.1qcNPevyGgjtz3SjiBeohtu', 'developer');

-- ROLES
INSERT INTO rol (nombre, descripcion) VALUES
('Gestor', 'Gestor de proyecto'),
('Desarrollador', 'Desarrollador de software'),
('Control de Calidad', 'Especialista en control de calidad'),
('Diseñador', 'Diseñador gráfico'),
('Analista', 'Analista de sistemas');

-- CLIENTES
INSERT INTO cliente (nombre, contacto_email, telefono, direccion) VALUES
('Empresa A - Soluciones Retail', 'contacto@empresaa.com', '+34 900 123 456', 'Calle Mayor 1, Madrid'),
('Empresa B - TechCorp Internacional', 'info@empresab.com', '+34 900 123 457', 'Avenida Diagonal 100, Barcelona'),
('Banco Nacional', 'contacto@banconacional.com', '+34 900 123 458', 'Gran Vía 50, Madrid'),
('MediHealth - Servicios de Salud', 'info@medihealth.com', '+34 900 123 459', 'Paseo de Gracia 25, Barcelona'),
('EduLearn - Plataforma Educativa', 'contacto@edulearn.com', '+34 900 123 460', 'Calle Serrano 10, Madrid'),
('Construcciones García S.L.', 'gerencia@construccionesgarcia.es', '+34 911 234 567', 'Calle de la Construcción 45, Valencia'),
('Restaurantes Mediterráneos', 'reservas@restmediterraneos.com', '+34 912 345 678', 'Plaza del Mar 12, Málaga');

-- PROYECTOS
INSERT INTO proyecto (id_cliente, nombre, descripcion, fecha_inicio, fecha_fin, estado) VALUES
(1, 'Sistema de Inventarios Inteligente', 'Plataforma completa de gestión de inventario con inteligencia artificial para predicción de stock y análisis en tiempo real. Incluye módulos de compras, ventas y almacén.', '2024-01-15', '2024-06-30', 'Finalizado'),
(2, 'Red Corporativa de Alta Disponibilidad', 'Infraestructura de red empresarial con redundancia, seguridad avanzada y monitoreo 24/7. Implementación de sistemas de respaldo automático.', '2024-08-01', '2025-03-15', 'Activo'),
(3, 'Aplicación Móvil Bancaria Segura', 'Aplicación móvil multiplataforma para banca digital con autenticación biométrica y cifrado end-to-end. Cumplimiento normativo PCI-DSS.', '2023-10-01', '2024-09-30', 'Finalizado'),
(4, 'Portal de Telemedicina', 'Plataforma de telemedicina con videoconsultas en tiempo real, historial médico electrónico y prescripción digital. Certificación HIPAA.', '2024-09-15', '2025-06-30', 'Activo'),
(5, 'Sistema de Gestión de Aprendizaje (LMS)', 'Plataforma educativa completa con cursos online, evaluaciones automatizadas y gamificación. Soporte para múltiples idiomas.', '2024-02-01', '2024-08-31', 'Finalizado'),
(6, 'Sistema de Gestión de Obras', 'Plataforma para gestión integral de proyectos de construcción: seguimiento de obras, materiales, personal y presupuestos.', '2024-11-01', '2025-05-31', 'Activo'),
(7, 'Sistema de Reservas Online', 'Plataforma web y móvil para gestión de reservas de restaurantes con integración de pagos y sistema de fidelización.', '2024-10-15', '2025-02-28', 'Activo');

-- PERSONAL DEL EQUIPO
INSERT INTO personal_equipo (id_proyecto, id_rol, nombre, email, telefono) VALUES
-- Proyecto 1: Sistema de Inventarios
(1, 1, 'María González', 'maria.gonzalez@empresa.com', '+34 600 111 222'),
(1, 2, 'Juan López', 'juan.lopez@empresa.com', '+34 600 222 333'),
(1, 2, 'Ana Martínez', 'ana.martinez@empresa.com', '+34 600 333 444'),
(1, 3, 'Carlos Ruiz', 'carlos.ruiz@empresa.com', '+34 600 444 555'),

-- Proyecto 2: Red Corporativa
(2, 1, 'Pedro Sánchez', 'pedro.sanchez@empresa.com', '+34 600 555 666'),
(2, 2, 'Laura Fernández', 'laura.fernandez@empresa.com', '+34 600 666 777'),
(2, 2, 'Miguel Rodríguez', 'miguel.rodriguez@empresa.com', '+34 600 777 888'),

-- Proyecto 3: App Bancaria
(3, 1, 'Sofía García', 'sofia.garcia@empresa.com', '+34 600 888 999'),
(3, 2, 'David Pérez', 'david.perez@empresa.com', '+34 600 999 000'),
(3, 3, 'Elena Torres', 'elena.torres@empresa.com', '+34 600 000 111'),

-- Proyecto 4: Telemedicina
(4, 1, 'Roberto Jiménez', 'roberto.jimenez@empresa.com', '+34 600 111 000'),
(4, 2, 'Carmen Muñoz', 'carmen.munoz@empresa.com', '+34 600 222 111'),
(4, 4, 'Isabel Ramírez', 'isabel.ramirez@empresa.com', '+34 600 333 222'),

-- Proyecto 5: LMS
(5, 1, 'Francisco Morales', 'francisco.morales@empresa.com', '+34 600 444 333'),
(5, 2, 'Patricia Herrera', 'patricia.herrera@empresa.com', '+34 600 555 444'),
(5, 5, 'Javier Ortega', 'javier.ortega@empresa.com', '+34 600 666 555'),

-- Proyecto 6: Gestión de Obras
(6, 1, 'Antonio Gutiérrez', 'antonio.gutierrez@empresa.com', '+34 600 777 666'),
(6, 2, 'Lucía Díaz', 'lucia.diaz@empresa.com', '+34 600 888 777'),
(6, 2, 'Manuel Castro', 'manuel.castro@empresa.com', '+34 600 999 888'),

-- Proyecto 7: Reservas Online
(7, 1, 'Rosa Méndez', 'rosa.mendez@empresa.com', '+34 600 000 999'),
(7, 2, 'Alberto Vargas', 'alberto.vargas@empresa.com', '+34 600 111 888'),
(7, 4, 'Natalia Campos', 'natalia.campos@empresa.com', '+34 600 222 777');

-- TAREAS
INSERT INTO tarea (id_proyecto, titulo, descripcion, prioridad, estado, id_responsable, fecha_vencimiento) VALUES
-- Proyecto 1
(1, 'Diseño de base de datos', 'Crear el esquema completo de base de datos para el sistema de inventarios. Incluir tablas de productos, categorías, proveedores y movimientos.', 5, 'Completada', 2, '2024-02-01'),
(1, 'Implementar módulo de compras', 'Desarrollar funcionalidad completa de gestión de compras: órdenes, recepciones y facturas.', 4, 'Completada', 2, '2024-03-15'),
(1, 'Sistema de alertas de stock', 'Implementar notificaciones automáticas cuando el stock esté por debajo del mínimo establecido.', 3, 'Completada', 3, '2024-04-30'),
(1, 'Pruebas de integración', 'Realizar pruebas completas del sistema integrado con todos los módulos funcionando.', 5, 'Completada', 4, '2024-06-15'),

-- Proyecto 2
(2, 'Configuración de servidores', 'Instalar y configurar servidores principales y de respaldo con alta disponibilidad.', 5, 'En progreso', 5, '2024-12-15'),
(2, 'Implementar sistema de monitoreo', 'Configurar herramientas de monitoreo en tiempo real con alertas automáticas.', 4, 'En progreso', 6, '2025-01-30'),
(2, 'Documentación técnica', 'Elaborar documentación completa del sistema de red y procedimientos de mantenimiento.', 3, 'Pendiente', 7, '2025-02-28'),

-- Proyecto 3
(3, 'Desarrollo de autenticación biométrica', 'Implementar sistema de reconocimiento facial y huella dactilar para acceso seguro.', 5, 'Completada', 8, '2024-05-15'),
(3, 'Integración con sistemas bancarios', 'Conectar la aplicación con los sistemas core del banco mediante APIs seguras.', 5, 'Completada', 9, '2024-07-30'),
(3, 'Auditoría de seguridad', 'Realizar auditoría completa de seguridad y cumplimiento normativo PCI-DSS.', 5, 'Completada', 10, '2024-09-01'),

-- Proyecto 4
(4, 'Implementar videollamadas WebRTC', 'Desarrollar sistema de videoconsultas en tiempo real con calidad HD.', 4, 'En progreso', 11, '2025-01-30'),
(4, 'Módulo de historial médico', 'Crear sistema de almacenamiento y consulta de historiales médicos electrónicos.', 5, 'En progreso', 12, '2025-03-15'),
(4, 'Diseño de interfaz de usuario', 'Crear diseño intuitivo y accesible para pacientes y profesionales sanitarios.', 3, 'Pendiente', 13, '2025-04-30'),

-- Proyecto 5
(5, 'Sistema de cursos online', 'Desarrollar plataforma para creación y gestión de cursos con contenido multimedia.', 4, 'Completada', 14, '2024-05-30'),
(5, 'Módulo de evaluaciones', 'Implementar sistema de exámenes y evaluaciones con corrección automática.', 4, 'Completada', 15, '2024-06-30'),
(5, 'Sistema de gamificación', 'Desarrollar sistema de puntos, logros y rankings para motivar a los estudiantes.', 3, 'Completada', 16, '2024-07-15'),

-- Proyecto 6
(6, 'Módulo de gestión de materiales', 'Desarrollar sistema para control de inventario de materiales de construcción.', 4, 'En progreso', 17, '2025-01-15'),
(6, 'Sistema de seguimiento de obras', 'Implementar dashboard para seguimiento en tiempo real del progreso de obras.', 5, 'En progreso', 18, '2025-02-28'),
(6, 'Gestión de presupuestos', 'Crear módulo para creación y control de presupuestos de obras.', 4, 'Pendiente', 19, '2025-03-31'),

-- Proyecto 7
(7, 'Sistema de reservas online', 'Desarrollar plataforma web para que los clientes puedan hacer reservas online.', 5, 'En progreso', 20, '2024-12-31'),
(7, 'Integración de pagos', 'Integrar pasarela de pagos para reservas con depósito.', 4, 'Pendiente', 21, '2025-01-31'),
(7, 'Aplicación móvil', 'Desarrollar aplicación móvil nativa para iOS y Android con sistema de reservas.', 4, 'Pendiente', 22, '2025-02-28');
