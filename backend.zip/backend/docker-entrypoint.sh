#!/bin/sh
set -e

echo "🚀 Iniciando script de entrada del backend..."

# Cambiar al directorio de trabajo
cd /app || {
  echo "❌ Error: No se pudo cambiar al directorio /app"
  exit 1
}

echo "📂 Directorio actual: $(pwd)"
echo "📋 Listando archivos en /app:"
ls -la /app | head -10

echo "📋 Verificando node_modules..."

# Verificar si node_modules existe y tiene bcryptjs (dependencia crítica)
if [ ! -d "node_modules" ] || [ ! -d "node_modules/bcryptjs" ]; then
  echo "📦 node_modules no existe o está incompleto. Instalando dependencias..."
  
  # Verificar que package.json existe
  if [ ! -f "package.json" ]; then
    echo "❌ Error: package.json no encontrado en /app"
    exit 1
  fi
  
  echo "📦 Ejecutando npm install..."
  npm install --verbose
  
  echo "✅ Dependencias instaladas"
  
  # Verificar que bcryptjs se instaló correctamente
  if [ ! -d "node_modules/bcryptjs" ]; then
    echo "⚠️ bcryptjs no encontrado después de la instalación. Reinstalando..."
    npm install bcryptjs --save --verbose
  fi
else
  echo "✅ node_modules existe y tiene bcryptjs"
fi

# Verificación final
if [ ! -d "node_modules/bcryptjs" ]; then
  echo "❌ Error crítico: bcryptjs no está disponible después de todos los intentos"
  echo "📋 Contenido de node_modules:"
  ls -la node_modules | head -20
  exit 1
fi

echo "✅ Verificación completada. Todas las dependencias están disponibles."
echo "🎯 Ejecutando comando: $@"

# Ejecutar el comando original
exec "$@"

