import pool from '../config/database.js';

class Cliente {
    static async getAll() {
        const query = 'SELECT * FROM cliente ORDER BY nombre';
        const [rows] = await pool.execute(query);
        return rows;
    }

    static async getById(id) {
        const query = 'SELECT * FROM cliente WHERE id_cliente = ?';
        const [rows] = await pool.execute(query, [id]);
        return rows[0];
    }

    static async create(data) {
        const query = `
      INSERT INTO cliente (nombre, contacto_email, telefono, direccion)
      VALUES (?, ?, ?, ?)
    `;
        const values = [
            data.nombre, 
            data.contacto_email || data.email || null, 
            data.telefono || null, 
            data.direccion || null
        ];
        const [result] = await pool.execute(query, values);

        return this.getById(result.insertId);
    }

    static async update(id, data) {
        const query = `
      UPDATE cliente SET
        nombre = COALESCE(?, nombre),
        contacto_email = COALESCE(?, contacto_email),
        telefono = COALESCE(?, telefono),
        direccion = COALESCE(?, direccion)
      WHERE id_cliente = ?
    `;
        const values = [
            data.nombre || null,
            data.contacto_email || data.email || null,
            data.telefono || null,
            data.direccion || null,
            id
        ];
        await pool.execute(query, values);
        return this.getById(id);
    }

    static async delete(id) {
        const deleted = await this.getById(id);
        const query = 'DELETE FROM cliente WHERE id_cliente = ?';
        await pool.execute(query, [id]);
        return deleted;
    }
}

export default Cliente;
