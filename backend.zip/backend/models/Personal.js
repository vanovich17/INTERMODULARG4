import pool from '../config/database.js';

class Personal {
    static async getAll() {
        const query = `
            SELECT 
                pe.*, 
                r.nombre as rol_nombre, 
                r.descripcion as rol_descripcion,
                p.nombre as proyecto_nombre
            FROM personal_equipo pe
            JOIN rol r ON pe.id_rol = r.id_rol
            LEFT JOIN proyecto p ON pe.id_proyecto = p.id_proyecto
            ORDER BY pe.nombre
        `;
        const [rows] = await pool.execute(query);
        return rows;
    }

    static async getById(id) {
        const query = `
            SELECT 
                pe.*, 
                r.nombre as rol_nombre, 
                r.descripcion as rol_descripcion,
                p.nombre as proyecto_nombre
            FROM personal_equipo pe
            JOIN rol r ON pe.id_rol = r.id_rol
            LEFT JOIN proyecto p ON pe.id_proyecto = p.id_proyecto
            WHERE pe.id_personal = ?
        `;
        const [rows] = await pool.execute(query, [id]);
        return rows[0];
    }

    static async getByProyecto(idProyecto) {
        const query = `
            SELECT 
                pe.*, 
                r.nombre as rol_nombre, 
                r.descripcion as rol_descripcion
            FROM personal_equipo pe
            JOIN rol r ON pe.id_rol = r.id_rol
            WHERE pe.id_proyecto = ?
            ORDER BY pe.nombre
        `;
        const [rows] = await pool.execute(query, [idProyecto]);
        return rows;
    }

    static async create(data) {
        const query = `
      INSERT INTO personal_equipo (id_proyecto, id_rol, nombre, email, telefono)
      VALUES (?, ?, ?, ?, ?)
    `;
        const values = [
            data.id_proyecto,
            data.id_rol,
            data.nombre,
            data.email || null,
            data.telefono || null
        ];
        const [result] = await pool.execute(query, values);

        return this.getById(result.insertId);
    }

    static async update(id, data) {
        const query = `
      UPDATE personal_equipo SET
        id_proyecto = COALESCE(?, id_proyecto),
        id_rol = COALESCE(?, id_rol),
        nombre = COALESCE(?, nombre),
        email = COALESCE(?, email),
        telefono = COALESCE(?, telefono)
      WHERE id_personal = ?
    `;
        const values = [
            data.id_proyecto || null,
            data.id_rol || null,
            data.nombre || null,
            data.email || null,
            data.telefono || null,
            id
        ];
        await pool.execute(query, values);
        return this.getById(id);
    }

    static async delete(id) {
        const deleted = await this.getById(id);
        const query = 'DELETE FROM personal_equipo WHERE id_personal = ?';
        await pool.execute(query, [id]);
        return deleted;
    }
}

export default Personal;
