import pool from '../config/database.js';

class Proyecto {
  static async getAll() {
    const query = `
      SELECT 
        p.*,
        c.nombre as cliente_nombre,
        c.contacto_email as cliente_email
      FROM proyecto p
      LEFT JOIN cliente c ON p.id_cliente = c.id_cliente
      ORDER BY p.creado_en DESC
    `;
    const [rows] = await pool.execute(query);
    return rows;
  }

  static async getById(id) {
    const query = `
      SELECT 
        p.*,
        c.nombre as cliente_nombre,
        c.contacto_email as cliente_email,
        c.telefono as cliente_telefono,
        c.direccion as cliente_direccion
      FROM proyecto p
      LEFT JOIN cliente c ON p.id_cliente = c.id_cliente
      WHERE p.id_proyecto = ?
    `;
    const [rows] = await pool.execute(query, [id]);
    return rows[0];
  }

  static async create(data) {
    const query = `
      INSERT INTO proyecto (
        id_cliente, nombre, descripcion, fecha_inicio, fecha_fin, estado
      ) VALUES (?, ?, ?, ?, ?, ?)
    `;
    
    const idCliente = data.id_cliente ? (typeof data.id_cliente === 'string' ? parseInt(data.id_cliente) : data.id_cliente) : null;
    
    const values = [
      idCliente,
      data.nombre,
      data.descripcion || null,
      data.fecha_inicio || null,
      data.fecha_fin || null,
      data.estado || 'Activo'
    ];
    
    const [result] = await pool.execute(query, values);

    return this.getById(result.insertId);
  }

  static async update(id, data) {
    const query = `
      UPDATE proyecto SET
        id_cliente = COALESCE(?, id_cliente),
        nombre = COALESCE(?, nombre),
        descripcion = COALESCE(?, descripcion),
        fecha_inicio = COALESCE(?, fecha_inicio),
        fecha_fin = COALESCE(?, fecha_fin),
        estado = COALESCE(?, estado)
      WHERE id_proyecto = ?
    `;
    const values = [
      data.id_cliente || null,
      data.nombre || null,
      data.descripcion || null,
      data.fecha_inicio || null,
      data.fecha_fin || null,
      data.estado || null,
      id
    ];
    await pool.execute(query, values);
    return this.getById(id);
  }

  static async delete(id) {
    const deleted = await this.getById(id);
    const query = 'DELETE FROM proyecto WHERE id_proyecto = ?';
    await pool.execute(query, [id]);
    return deleted;
  }

  static async getTeam(id) {
    const query = `
      SELECT pe.*, r.nombre as rol_nombre, r.descripcion as rol_descripcion
      FROM personal_equipo pe
      JOIN rol r ON pe.id_rol = r.id_rol
      WHERE pe.id_proyecto = ?
    `;
    const [rows] = await pool.execute(query, [id]);
    return rows;
  }
}

export default Proyecto;
