import pool from '../config/database.js';

class Tarea {
  static async getAll() {
    const query = `
      SELECT 
        t.*, 
        p.nombre as nombre_proyecto,
        pe.nombre as asignado_nombre,
        pe.email as asignado_email
      FROM tarea t
      LEFT JOIN proyecto p ON t.id_proyecto = p.id_proyecto
      LEFT JOIN personal_equipo pe ON t.id_responsable = pe.id_personal
      ORDER BY t.fecha_creacion DESC
    `;
    const [rows] = await pool.execute(query);
    return rows;
  }

  static async getById(id) {
    const query = `
      SELECT 
        t.*, 
        p.nombre as nombre_proyecto,
        pe.nombre as asignado_nombre,
        pe.email as asignado_email
      FROM tarea t
      LEFT JOIN proyecto p ON t.id_proyecto = p.id_proyecto
      LEFT JOIN personal_equipo pe ON t.id_responsable = pe.id_personal
      WHERE t.id_tarea = ?
    `;
    const [rows] = await pool.execute(query, [id]);
    return rows[0];
  }

  static async getByProyecto(idProyecto) {
    const query = `
      SELECT 
        t.*, 
        pe.nombre as asignado_nombre,
        pe.email as asignado_email
      FROM tarea t
      LEFT JOIN personal_equipo pe ON t.id_responsable = pe.id_personal
      WHERE t.id_proyecto = ?
      ORDER BY t.fecha_creacion DESC
    `;
    const [rows] = await pool.execute(query, [idProyecto]);
    return rows;
  }

  static async create(data) {
    // Convertir prioridad de texto a número si es necesario
    let prioridad = data.prioridad;
    if (typeof prioridad === 'string') {
      const prioridades = { 'Alta': 5, 'Media': 3, 'Baja': 1 };
      prioridad = prioridades[prioridad] || 3;
    }
    if (!prioridad || prioridad < 1 || prioridad > 5) {
      prioridad = 3;
    }

    // Usar estado directamente en español
    let estado = data.estado || 'Pendiente';
    // Normalizar a los valores válidos del ENUM
    const estadosValidos = ['Pendiente', 'En progreso', 'Bloqueada', 'Completada'];
    if (!estadosValidos.includes(estado)) {
      estado = 'Pendiente';
    }

    const query = `
      INSERT INTO tarea (id_proyecto, titulo, descripcion, prioridad, estado, id_responsable, fecha_vencimiento)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `;
    const values = [
      data.id_proyecto,
      data.titulo,
      data.descripcion || null,
      prioridad,
      estado,
      data.id_responsable || data.id_asignado || null,
      data.fecha_vencimiento || null
    ];
    const [result] = await pool.execute(query, values);

    return this.getById(result.insertId);
  }

  static async update(id, data) {
    // Convertir prioridad si es necesario
    let prioridad = data.prioridad;
    if (typeof prioridad === 'string') {
      const prioridades = { 'Alta': 5, 'Media': 3, 'Baja': 1 };
      prioridad = prioridades[prioridad] || null;
    }

    // Usar estado directamente en español
    let estado = data.estado;
    if (estado) {
      // Normalizar a los valores válidos del ENUM
      const estadosValidos = ['Pendiente', 'En progreso', 'Bloqueada', 'Completada'];
      if (!estadosValidos.includes(estado)) {
        estado = null; // Mantener el valor actual si no es válido
      }
    }

    const query = `
      UPDATE tarea SET
        id_proyecto = COALESCE(?, id_proyecto),
        titulo = COALESCE(?, titulo),
        descripcion = COALESCE(?, descripcion),
        prioridad = COALESCE(?, prioridad),
        estado = COALESCE(?, estado),
        id_responsable = COALESCE(?, id_responsable),
        fecha_vencimiento = COALESCE(?, fecha_vencimiento)
      WHERE id_tarea = ?
    `;
    const values = [
      data.id_proyecto || null,
      data.titulo || null,
      data.descripcion || null,
      prioridad || null,
      estado || null,
      data.id_responsable || data.id_asignado || null,
      data.fecha_vencimiento || null,
      id
    ];
    await pool.execute(query, values);
    return this.getById(id);
  }

  static async delete(id) {
    const deleted = await this.getById(id);
    const query = 'DELETE FROM tarea WHERE id_tarea = ?';
    await pool.execute(query, [id]);
    return deleted;
  }
}

export default Tarea;
