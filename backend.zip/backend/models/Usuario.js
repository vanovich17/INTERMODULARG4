import pool from '../config/database.js';
import bcrypt from 'bcryptjs';

class Usuario {
    static async findByEmail(email) {
        const query = 'SELECT * FROM usuarios WHERE email = ?';
        const [rows] = await pool.execute(query, [email]);
        return rows[0];
    }

    static async findById(id) {
        const query = 'SELECT id_usuario, nombre, email, rol FROM usuarios WHERE id_usuario = ?';
        const [rows] = await pool.execute(query, [id]);
        return rows[0];
    }

    static async create(nombre, email, password, rol = 'usuario') {
        const hashedPassword = await bcrypt.hash(password, 10);
        const query = `
      INSERT INTO usuarios (nombre, email, password_hash, rol)
      VALUES (?, ?, ?, ?)
    `;
        const [result] = await pool.execute(query, [nombre, email, hashedPassword, rol]);

        // Return the created user
        return {
            id_usuario: result.insertId,
            nombre,
            email,
            rol
        };
    }

    static async verifyPassword(plainPassword, hashedPassword) {
        return await bcrypt.compare(plainPassword, hashedPassword);
    }

    static async getAll() {
        const query = 'SELECT id_usuario, nombre, email, rol, fecha_creacion FROM usuarios ORDER BY fecha_creacion DESC';
        const [rows] = await pool.execute(query);
        return rows;
    }
}

export default Usuario;
