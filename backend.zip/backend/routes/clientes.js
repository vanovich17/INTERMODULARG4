import express from 'express';
import Cliente from '../models/Cliente.js';

const router = express.Router();

router.get('/', async (req, res) => {
    try {
        const clientes = await Cliente.getAll();
        res.json(clientes);
    } catch (error) {
        res.status(500).json({ message: 'Error al obtener clientes' });
    }
});

router.get('/:id', async (req, res) => {
    try {
        const cliente = await Cliente.getById(req.params.id);
        if (!cliente) return res.status(404).json({ message: 'Cliente no encontrado' });
        res.json(cliente);
    } catch (error) {
        res.status(500).json({ message: 'Error al obtener cliente' });
    }
});

router.post('/', async (req, res) => {
    try {
        const cliente = await Cliente.create(req.body);
        res.status(201).json(cliente);
    } catch (error) {
        res.status(500).json({ message: 'Error al crear cliente' });
    }
});

router.put('/:id', async (req, res) => {
    try {
        const cliente = await Cliente.update(req.params.id, req.body);
        if (!cliente) return res.status(404).json({ message: 'Cliente no encontrado' });
        res.json(cliente);
    } catch (error) {
        res.status(500).json({ message: 'Error al actualizar cliente' });
    }
});

router.delete('/:id', async (req, res) => {
    try {
        const cliente = await Cliente.delete(req.params.id);
        if (!cliente) return res.status(404).json({ message: 'Cliente no encontrado' });
        res.json({ message: 'Cliente eliminado', cliente });
    } catch (error) {
        res.status(500).json({ message: 'Error al eliminar cliente' });
    }
});

export default router;
