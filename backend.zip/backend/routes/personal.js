import express from 'express';
import Personal from '../models/Personal.js';

const router = express.Router();

router.get('/', async (req, res) => {
    try {
        const personal = await Personal.getAll();
        res.json(personal);
    } catch (error) {
        res.status(500).json({ message: 'Error al obtener personal' });
    }
});

router.get('/:id', async (req, res) => {
    try {
        const persona = await Personal.getById(req.params.id);
        if (!persona) return res.status(404).json({ message: 'Personal no encontrado' });
        res.json(persona);
    } catch (error) {
        res.status(500).json({ message: 'Error al obtener personal' });
    }
});

router.post('/', async (req, res) => {
    try {
        const persona = await Personal.create(req.body);
        res.status(201).json(persona);
    } catch (error) {
        res.status(500).json({ message: 'Error al crear personal' });
    }
});

router.put('/:id', async (req, res) => {
    try {
        const persona = await Personal.update(req.params.id, req.body);
        if (!persona) return res.status(404).json({ message: 'Personal no encontrado' });
        res.json(persona);
    } catch (error) {
        res.status(500).json({ message: 'Error al actualizar personal' });
    }
});

router.delete('/:id', async (req, res) => {
    try {
        const persona = await Personal.delete(req.params.id);
        if (!persona) return res.status(404).json({ message: 'Personal no encontrado' });
        res.json({ message: 'Personal eliminado', persona });
    } catch (error) {
        res.status(500).json({ message: 'Error al eliminar personal' });
    }
});

export default router;
