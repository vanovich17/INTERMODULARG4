import express from 'express';
import {
    getAllProyectos,
    getProyectoById,
    createProyecto,
    updateProyecto,
    deleteProyecto,
    getProyectoTeam
} from '../controllers/proyectosController.js';

const router = express.Router();

// Rutas públicas (sin autenticación para simplificar)
router.get('/', getAllProyectos);
router.get('/:id', getProyectoById);
router.get('/:id/team', getProyectoTeam);
router.post('/', createProyecto);
router.put('/:id', updateProyecto);
router.delete('/:id', deleteProyecto);

export default router;
