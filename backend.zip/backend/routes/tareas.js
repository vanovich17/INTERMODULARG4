import express from 'express';
import Tarea from '../models/Tarea.js';

const router = express.Router();

router.get('/', async (req, res) => {
    try {
        const tareas = await Tarea.getAll();
        res.json(tareas);
    } catch (error) {
        res.status(500).json({ message: 'Error al obtener tareas' });
    }
});

router.get('/:id', async (req, res) => {
    try {
        const tarea = await Tarea.getById(req.params.id);
        if (!tarea) return res.status(404).json({ message: 'Tarea no encontrada' });
        res.json(tarea);
    } catch (error) {
        res.status(500).json({ message: 'Error al obtener tarea' });
    }
});

router.get('/proyecto/:idProyecto', async (req, res) => {
    try {
        const tareas = await Tarea.getByProyecto(req.params.idProyecto);
        res.json(tareas);
    } catch (error) {
        res.status(500).json({ message: 'Error al obtener tareas del proyecto' });
    }
});

router.post('/', async (req, res) => {
    try {
        const tarea = await Tarea.create(req.body);
        res.status(201).json(tarea);
    } catch (error) {
        res.status(500).json({ message: 'Error al crear tarea' });
    }
});

router.put('/:id', async (req, res) => {
    try {
        const tarea = await Tarea.update(req.params.id, req.body);
        if (!tarea) return res.status(404).json({ message: 'Tarea no encontrada' });
        res.json(tarea);
    } catch (error) {
        res.status(500).json({ message: 'Error al actualizar tarea' });
    }
});

router.delete('/:id', async (req, res) => {
    try {
        const tarea = await Tarea.delete(req.params.id);
        if (!tarea) return res.status(404).json({ message: 'Tarea no encontrada' });
        res.json({ message: 'Tarea eliminada', tarea });
    } catch (error) {
        res.status(500).json({ message: 'Error al eliminar tarea' });
    }
});

export default router;
