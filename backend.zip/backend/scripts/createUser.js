import pool from '../config/database.js';
import bcrypt from 'bcryptjs';

// Obtener argumentos de la línea de comandos
const args = process.argv.slice(2);

if (args.length < 3) {
  console.log(`
📝 Uso: node scripts/createUser.js <nombre> <email> <password> [rol]

Ejemplos:
  node scripts/createUser.js "Juan Pérez" juan@empresa.com miPassword123 admin
  node scripts/createUser.js "Ana García" ana@empresa.com miPassword123 project_manager
  node scripts/createUser.js "Carlos Ruiz" carlos@empresa.com miPassword123 developer
  node scripts/createUser.js "Usuario Test" test@empresa.com miPassword123 usuario

Roles disponibles: admin, project_manager, developer, usuario
`);
  process.exit(1);
}

const [nombre, email, password, rol = 'usuario'] = args;

async function createUser() {
  try {
    console.log('🔄 Creando nuevo usuario...\n');

    // Verificar si el email ya existe
    const [existing] = await pool.execute('SELECT * FROM usuarios WHERE email = ?', [email]);
    if (existing.length > 0) {
      console.error('❌ Error: El email ya está registrado');
      process.exit(1);
    }

    // Generar hash de la contraseña
    const passwordHash = await bcrypt.hash(password, 10);
    console.log('✅ Hash de contraseña generado');

    // Insertar usuario
    const query = `
      INSERT INTO usuarios (nombre, email, password_hash, rol)
      VALUES (?, ?, ?, ?)
    `;
    const [result] = await pool.execute(query, [nombre, email, passwordHash, rol]);

    console.log('\n✅ Usuario creado exitosamente!');
    console.log(`   ID: ${result.insertId}`);
    console.log(`   Nombre: ${nombre}`);
    console.log(`   Email: ${email}`);
    console.log(`   Rol: ${rol}`);
    console.log(`   Contraseña: ${password} (hasheada)`);

    // Verificar que funciona
    const [verification] = await pool.execute('SELECT * FROM usuarios WHERE email = ?', [email]);
    const isValid = await bcrypt.compare(password, verification[0].password_hash);
    console.log(`\n🔐 Verificación de contraseña: ${isValid ? '✅ Correcta' : '❌ Incorrecta'}`);

    await pool.end();
    process.exit(0);
  } catch (error) {
    console.error('❌ Error al crear usuario:', error.message);
    await pool.end();
    process.exit(1);
  }
}

createUser();





