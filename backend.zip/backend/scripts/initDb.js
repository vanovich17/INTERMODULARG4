import pool from '../config/database.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function initDatabase() {
    try {
        console.log('🔄 Inicializando base de datos...\n');

        // Leer y ejecutar schema.sql
        const schemaPath = path.join(__dirname, '../db/schema.sql');
        const schema = fs.readFileSync(schemaPath, 'utf8');

        console.log('📝 Creando tablas...');
        // Ejecutar cada statement por separado para evitar errores
        const statements = schema.split(';').filter(s => s.trim().length > 0);
        for (const statement of statements) {
            if (statement.trim()) {
                try {
                    await pool.execute(statement);
                } catch (err) {
                    // Ignorar errores de "tabla ya existe" o "índice ya existe"
                    if (!err.message.includes('already exists') && !err.message.includes('Duplicate')) {
                        console.warn('⚠️  Advertencia:', err.message);
                    }
                }
            }
        }
        console.log('✅ Tablas creadas\n');

        // Verificar si ya hay datos
        const [existingData] = await pool.execute('SELECT COUNT(*) as count FROM proyectos');
        if (existingData[0].count > 0) {
            console.log('ℹ️  La base de datos ya contiene datos.');
            console.log('   Para rellenarla de nuevo, primero elimina los datos existentes.\n');
        } else {
            // Leer y ejecutar seed.sql
            const seedPath = path.join(__dirname, '../db/seed.sql');
            const seed = fs.readFileSync(seedPath, 'utf8');

            console.log('🌱 Insertando datos de prueba...');
            const seedStatements = seed.split(';').filter(s => s.trim().length > 0);
            for (const statement of seedStatements) {
                if (statement.trim()) {
                    try {
                        await pool.execute(statement);
                    } catch (err) {
                        // Ignorar errores de duplicados
                        if (!err.message.includes('Duplicate entry')) {
                            console.warn('⚠️  Advertencia al insertar:', err.message);
                        }
                    }
                }
            }
            console.log('✅ Datos insertados\n');
        }

        console.log('🎉 Base de datos inicializada correctamente!\n');

        // Mostrar estadísticas
        const [usuarios] = await pool.execute('SELECT COUNT(*) as count FROM usuarios');
        const [proyectos] = await pool.execute('SELECT COUNT(*) as count FROM proyectos');
        const [clientes] = await pool.execute('SELECT COUNT(*) as count FROM clientes');
        const [personal] = await pool.execute('SELECT COUNT(*) as count FROM personal');
        const [tareas] = await pool.execute('SELECT COUNT(*) as count FROM tareas');

        console.log('📊 Estadísticas:');
        console.log(`   - Usuarios: ${usuarios[0].count}`);
        console.log(`   - Proyectos: ${proyectos[0].count}`);
        console.log(`   - Clientes: ${clientes[0].count}`);
        console.log(`   - Personal: ${personal[0].count}`);
        console.log(`   - Tareas: ${tareas[0].count}\n`);

        await pool.end();
        process.exit(0);
    } catch (error) {
        console.error('❌ Error al inicializar la base de datos:', error);
        await pool.end();
        process.exit(1);
    }
}

initDatabase();
