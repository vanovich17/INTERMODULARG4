import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import pool from './config/database.js';

// Importar rutas
import authRoutes from './routes/auth.js';
import proyectosRoutes from './routes/proyectos.js';
import clientesRoutes from './routes/clientes.js';
import personalRoutes from './routes/personal.js';
import tareasRoutes from './routes/tareas.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 4000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Configurar charset UTF-8 para todas las respuestas
app.use((req, res, next) => {
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    next();
});

// Log de requests (desarrollo)
app.use((req, res, next) => {
    console.log(`${req.method} ${req.path}`);
    next();
});

// Rutas
app.use('/api/auth', authRoutes);
app.use('/api/proyectos', proyectosRoutes);
app.use('/api/clientes', clientesRoutes);
app.use('/api/personal', personalRoutes);
app.use('/api/tareas', tareasRoutes);

// Ruta de health check
app.get('/api/health', (req, res) => {
    res.json({ status: 'OK', message: 'API funcionando correctamente' });
});

// Ruta raíz
app.get('/', (req, res) => {
    res.json({
        message: 'API de Gestión de Proyectos',
        version: '1.0.0',
        endpoints: {
            auth: '/api/auth',
            proyectos: '/api/proyectos',
            clientes: '/api/clientes',
            personal: '/api/personal',
            tareas: '/api/tareas'
        }
    });
});

// Manejo de errores 404
app.use((req, res) => {
    res.status(404).json({ message: 'Ruta no encontrada' });
});

// Manejo de errores global
app.use((err, req, res, next) => {
    console.error('Error:', err);
    res.status(500).json({ message: 'Error interno del servidor' });
});

// Iniciar servidor
app.listen(PORT, '0.0.0.0', () => {
    console.log(`\n🚀 Servidor corriendo en http://0.0.0.0:${PORT}`);
    console.log(`📚 API disponible en http://localhost:${PORT}/api`);
    console.log(`\n📋 Endpoints disponibles:`);
    console.log(`   - POST /api/auth/login`);
    console.log(`   - POST /api/auth/register`);
    console.log(`   - GET  /api/auth/me`);
    console.log(`   - GET  /api/proyectos`);
    console.log(`   - GET  /api/clientes`);
    console.log(`   - GET  /api/personal`);
    console.log(`   - GET  /api/tareas`);
    console.log(`\n💡 Usa Ctrl+C para detener el servidor\n`);
});

// Manejo de cierre graceful
process.on('SIGINT', async () => {
    console.log('\n\n👋 Cerrando servidor...');
    await pool.end();
    process.exit(0);
});
